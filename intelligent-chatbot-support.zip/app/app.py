import streamlit as st
from transformers import pipeline

st.set_page_config(page_title="AI Chatbot Support", layout="wide")
st.title("🤖 Intelligent Customer Support Chatbot")

st.markdown("Ask any support-related question!")

@st.cache_resource
def load_chatbot():
    return pipeline("text-generation", model="microsoft/DialoGPT-medium")

chatbot = load_chatbot()

user_input = st.text_input("You:", "")

if user_input:
    response = chatbot(user_input, max_length=100, num_return_sequences=1)[0]['generated_text']
    st.markdown(f"**Bot:** {response}")
