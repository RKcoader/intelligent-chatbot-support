# Revolutionizing Customer Support with an Intelligent Chatbot

This project aims to automate customer service using an AI chatbot built on HuggingFace Transformers and deployed via Streamlit.

## Features
- Understands natural language queries
- Provides real-time, automated support
- Easy-to-deploy using Streamlit

## Setup
```bash
cd app
pip install -r requirements.txt
streamlit run app.py
```

## Demo
(Insert Hugging Face or Streamlit Cloud link here)
